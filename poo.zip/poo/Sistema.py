from Cliente import Cliente
from Produto import Produto
import os

def cadastrarProdutos(listaProdutos):
    os.system("cls")
    print("****** CADASTRO DE PRODUTOS *******\n")
    cod = int(input("Informe o código do produto: "))
    mar = input("Informe a marca: ")
    des = input("Descrição do produto: ")
    uni = input("Informe o símbolo da unidade de medida: ")
    pre = float(input("Preços: "))

    pro = Produto(cod, mar, des, uni, pre)
    listaProdutos += [pro]
    print("Produto cadastrado com sucesso!")

def listarProdutosCadastrados(listaProdutos):
    os.system("cls")
    print("****** LISTAGEM DE PRODUTOS *******\n")
    if len(listaProdutos) == 0:
        print("Não existem produtos cadastrados!")
    else:
        for p in listaProdutos:
            input(p.listarDados())

def cadastrarClientes(listaClientes, listaProdutos):
    os.system("cls")
    print("****** CADASTRO DE CLIENTES *******\n")
    cpf = input("Informe o CPF do cliente: ")
    nom = input("Informe o nome do cliente: ")
    ida = int(input("Informe a idade: "))
    end = input("Informe o endereço: ")

    cli = Cliente(cpf, nom, ida, end)
    if realizarPedidosCompra(cli, listaProdutos):
        listaClientes += [cli]
        print("Cliente cadastrado com sucesso! =)")
    else:
        print("Cliente não cadastrado! comprar pelo menos 1 produto! =/")

def realizarPedidosCompra(cliente, listaProdutos):
    comprou = False
    for p in listaProdutos:
        print(p.listarDados())
        decisao = input("Deseja comprar esse produto? (s/n)")
        if decisao == "s":
            cliente.addProduto(p)
            comprou = True
    return comprou

listaClientes = []
listaProdutos = []
while True:
    os.system("cls")
    print("****** MERCADINHO DO TOBIAS *******\n")
    print("(1) Cadastrar Produtos")
    print("(2) Listar Produtos")
    print("(3) Cadastrar Clientes")
    print("(4) Listar Clientes")
    print("(5) Realizar Pedidos de Compra")
    print("(6) Listar Pedidos de Compra")
    print("(7) Sair\n")
    opcao = int(input("Escolha a sua opção: "))
    if opcao == 1:
        cadastrarProdutos(listaProdutos)
    elif opcao == 2:
        listarProdutosCadastrados(listaProdutos)
    elif opcao == 3:
        cadastrarClientes(listaClientes)
    elif opcao == 4:
        pass
    elif opcao == 5:
        cli = None
        realizarPedidosCompra(cli, listaProdutos)
    elif opcao == 6:
        pass
    elif opcao == 7:
        break
    else:
        print("\nOpção inválida! =/")
    input()