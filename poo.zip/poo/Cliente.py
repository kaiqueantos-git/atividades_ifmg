from Produto import Produto

class Cliente:
    def _init_(self, c: str, n: str, i: int, e: str, p: Produto) -> None:
        self.CPF = c
        self.nome = n
        self.idade = i
        self.endereco = e
        self.listaProdutos = [p]

    def addProduto(self, prod: Produto) -> None:
        self.listaProdutos += [prod]

    def regPedido(self, tipo: str) -> float:
        total = 0
        for p in self.listaProdutos:
            total += p.preco
        if tipo in ["Pix", "Dinheiro"]:
            total *= 0.90
        elif tipo == "Débito":
            total *= 0.95
        else:
            vezes = int(input("Em quantas vezes? "))
            while vezes > 10:
                print("Não é permitido!\n")
                vezes = int(input("Em quantas vezes? "))
            if vezes > 3:
                for juros in range(0, vezes - 3):
                    total *= 1.05
            parcela = total / vezes
            print(f"R$ {total} em {vezes} parcela(s) de R$ {parcela}.")
        return total