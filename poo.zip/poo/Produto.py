class Produto:
    def _init_(self, cod, marca, desc, uni, preco):
        self.codigo = cod
        self.marca = marca
        self.descricao = desc
        self.uniMed = uni
        self.preco = preco

    def listarDados(self):
        dados = f"Código: {self.codigo}\n"
        dados += f"Marca: {self.marca}\n"
        dados += f"Descrição: {self.descricao}\n"
        dados += f"Preços: R$ {self.preco} (por {self.uniMed})\n"
        return dados